# AWS Deployment Guide: AI Resume Matcher

This guide details the steps to deploy your Python FastAPI & Vanilla HTML application to AWS so it can be accessed publicly via a web link.

Since your application uses Python, FastAPI, and serves static files seamlessly, the easiest and most modern way to deploy this without managing underlying servers is **AWS App Runner** or **AWS Elastic Beanstalk**. 

This guide uses **AWS Elastic Beanstalk**, as it perfectly handles standard Python web servers out-of-the-box.

---

## Prerequisites
1. **An AWS Account**: You must have an active AWS account.
2. **AWS CLI & EB CLI**: Installed on your Mac.
   - Install AWS CLI: Download from AWS or use Homebrew (`brew install awscli`)
   - Install EB CLI (Elastic Beanstalk CLI): `pip install awsebcli`
3. **Your Gemini API Key**: Ready to be added as a secure environment variable.

---

## Step 1: Prepare the Project for AWS

AWS Elastic Beanstalk automatically looks for a file named `application.py` or a specific command to run your server. We need to make a tiny adjustment so AWS knows how to run FastAPI.

1. **Create a `Procfile`**:
   In your root project folder (`/Users/govindandhanasekaran/Dev/AntiGravity/Capstone-SGJob`), create a file exactly named `Procfile` (no extension) and add the following line:
   ```text
   web: uvicorn main:app --host 0.0.0.0 --port 8000
   ```
   *This tells AWS exactly what command to run to launch your server on the public port.*

2. **Ensure `requirements.txt` is updated**:
   Double-check that all your packages (fastapi, uvicorn, google-genai, etc.) are in the `requirements.txt` file. You can run:
   ```bash
   pip freeze > requirements.txt
   ```

---

## Step 2: Zip Your Project

Instead of using the command line, we will upload the project as a `.zip` file to AWS.

1. Open **Finder** and navigate to your project folder (`Capstone-SGJob`).
2. Select **all the files and folders** *inside* the project folder (including `main.py`, `Procfile`, `requirements.txt`, `frontend/`, and `backend/`).
   * **CRITICAL**: Do **NOT** select or zip the `.venv` folder! AWS Linux cannot read Mac virtual environments. AWS will automatically install its own Python virtual environment using your `requirements.txt`.
   * *Do **not** zip the parent `Capstone-SGJob` folder itself. Zip the contents.*
3. Right-click the selected files and click **Compress**.
4. Rename the newly created archive to `resume-matcher-app.zip`.

---

## Step 3: Create the AWS Environment via the Web Console

1. Log in to the [AWS Management Console](https://console.aws.amazon.com/).
2. Search for **Elastic Beanstalk** in the top search bar and click it.
3. Click the orange **Create application** button.
4. **Environment tier**: Leave it as "Web server environment".
5. **Application Information**:
   - Application name: `ai-resume-matcher`
6. **Platform**:
   - Platform: Choose **Python**.
   - Platform branch: Choose the latest **Python 3.9** (or whichever matches your local environment).
7. **Application Code**:
   - Select **Upload your code**.
   - Choose **Local file** -> **Choose file** and upload your `resume-matcher-app.zip`.
8. Scroll down and click **Next**.
9. **Service Access**: If you don't have an existing service role, choose "Create and use new service role". If you need an EC2 instance profile, create one in IAM (it will prompt you if missing). Click **Skip to Review** if available, or just click **Next** through the other steps leaving default settings.
10. Click **Submit** on the final review page.

AWS will now take 3-5 minutes to spawn your server.

---

## Step 4: Add Your Gemini API Key Securely

Your `GEMINI_API_KEY` should never be hardcoded or included in your ZIP file. You add it securely through the AWS dashboard.

1. Once your environment finishes creating (you see a green checkmark), click on your environment name on the left sidebar.
2. Click **Configuration** in the left sidebar.
3. Scroll down to the **Updates, monitoring, and routing** section and click **Edit**.
4. Scroll to the very bottom to the **Environment properties** section.
5. Add a new row:
   - **Name**: `GEMINI_API_KEY`
   - **Value**: `AIzaSyAqaa6...your_full_key...`
6. Click **Apply** at the bottom. AWS will quickly restart your app to inject the key.

---

## Step 5: Open Your Public Web Link!

Your application is now live on the internet!

On your Elastic Beanstalk Environment dashboard page, you will see a clickable URL under your environment name (e.g., `ai-resume-matcher-env.eba-xxxxxxx.us-east-1.elasticbeanstalk.com`). 

Click that link to open your live application. You can safely share this URL with anyone.

---

### Alternative: Vercel (Easiest Option outside AWS)
If you do not strictly require AWS, deploying a Python/FastAPI app is actually fastest on **Render** or **Vercel**. 
On those platforms, you simply link your GitHub repository, paste your `GEMINI_API_KEY` into their dashboard, and they give you a free SSL URL instantly without any command-line server configuration.
